#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <Pipes.h>
void vector_control_daemon();
float fpadd32f(float x, float y);
float fpsub32f(float x, float y);
uint32_t fpadd32fi(uint32_t x, uint32_t y);
uint32_t fpsub32fi(uint32_t x, uint32_t y);
float fpmul32f(float x, float y);
float fdiv32(float a, float b);

 
