float fdiv(float a, float b);
