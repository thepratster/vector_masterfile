void vector_control_daemon();
