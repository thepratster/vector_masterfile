#include "prog.h"
uint32_t fpsub32fi(uint32_t x, uint32_t y)
{
	return(x-y);
}
