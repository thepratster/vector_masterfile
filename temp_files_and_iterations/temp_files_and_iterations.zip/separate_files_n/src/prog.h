#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <Pipes.h>
void vector_control_daemon();
float fpadd32f(float x, float y);
float fpsub32f(float x, float y);
uint32_t fpadd32fi(uint32_t x, uint32_t y);
uint32_t fpsub32fi(uint32_t x, uint32_t y);
uint32_t udiv32(uint32_t dividend, uint32_t divisor);
float fpmul32f(float x, float y);
double fdiv32(double a, double b);
float iq_err_calc(float Lr, float torque_ref, float constant_1, float flux_rotor);
float rotor_flux_calc(float del_t, float Lm, float id, float flux_rotor_prev, float tau_new, float tau_r);
float omega_calc(float Lm, float iq, float tau_r, float flux_rotor);
float theta_calc(float omega_r, float omega_m, float del_t, float theta_prev);
//uint64_t udiv64(uint64_t dividend, uint32_t divisor);
 
