#include "prog.h"
float fpadd32f(float x, float y)
{
	return(x+y);
}
