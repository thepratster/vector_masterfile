#include "prog.h"
float fpmul32f(float x, float y)
{
	return(x*y);
}
