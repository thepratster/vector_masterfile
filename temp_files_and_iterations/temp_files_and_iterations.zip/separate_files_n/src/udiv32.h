uint32_t udiv32(uint32_t dividend, uint32_t divisor);
