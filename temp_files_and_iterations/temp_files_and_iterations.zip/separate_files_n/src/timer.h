#ifndef _timer_h_
#define _timer_h_

#include <stdint.h>
void countDownTimer(uint32_t time_count);
uint32_t getClockTime();

#endif
