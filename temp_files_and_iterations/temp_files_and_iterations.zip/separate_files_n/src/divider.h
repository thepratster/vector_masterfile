uint16_t udiv16(uint16_t dividend, uint16_t divisor, uint16_t* remainder);
